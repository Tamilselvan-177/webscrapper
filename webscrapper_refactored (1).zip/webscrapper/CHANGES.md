# Refactor: honest status reporting, bypass code removed

## Scope
This refactor does two things only:
1. Removes the Cloudflare/Akamai bypass code paths (stealth Playwright fallback,
   the "Obscura" remote anti-detect browser) that were built into the scraper
   layer.
2. Replaces silent `Count: 0` failures with an explicit, typed status so a
   caller (your agent, your frontend, whatever) can tell "blocked by bot
   defense" apart from "no matching jobs" apart from "network error".

It does **not** attempt to make Indeed/Totaljobs/StepStone return real jobs
via scraping. That requires Indeed's Publisher/XML Feed program and
StepStone Group's partner API respectively — separate integration work once
you have credentials, not a code fix.

## New file
- `app/core/errors.py` — `SourceStatus` enum (`ok` / `blocked` / `not_found` /
  `error`), `BlockedSourceError`, `ScraperResult`, and
  `detect_block_signature()` (a small fingerprint matcher for Cloudflare /
  Akamai / PerimeterX / DataDome block pages — used only to **label** what
  happened, never to react to it).

## Changed files
- `app/scrapers/base.py` — `search()` now returns a `ScraperResult`
  (`status`, `jobs`, `reason`) instead of a bare list, and instead of raising
  a generic `ScraperFetchError` that hid the cause.
- `app/scrapers/indeed.py`, `totaljobs.py`, `stepstone.py` — removed the
  Playwright + `playwright-stealth` fallback block entirely. Each now makes
  one honest HTTP request; if the response matches a known bot-defense
  signature (or is a bare 403/429/503), it raises `BlockedSourceError` with
  the concrete evidence instead of retrying with a stealth browser.
- `app/scrapers/description_fetcher.py` — removed the shared
  `fetch_with_browser()` that auto-escalated to a stealth headless browser on
  any 403/429/503 from **any** source (this was the broadest bypass surface —
  it applied even to non-Indeed/Totaljobs/StepStone sources). Replaced with
  plain-HTTP-only extraction, plus a narrow, explicitly-allowlisted
  (`JS_RENDER_ALLOWLIST`), non-stealth headless render for the couple of
  sources that need JS hydration but are not bot-defended (SEEK, Glassdoor).
  A block response is now logged and left alone, not retried.
- `app/core/browser_client.py` — removed default stealth-evasion application
  and the `OBSCURA_WS_URL` remote anti-detect-browser hook. Now a plain
  headless-Chromium client.
- `app/scrapers/factory.py` — added `SOURCE_TIERS` / `get_source_tier()` so
  Indeed/Monster/Workopolis (Cloudflare Turnstile) and Totaljobs/StepStone
  (Akamai) are labeled `blocked_pending_official_api` up front.
- `app/api/endpoints.py`:
  - `/jobs` now returns `{status, reason, source_tier, count, jobs}` and
    raises **HTTP 503** (not a quiet 200 with an empty list) when a source is
    blocked, so the response is unambiguous to any consumer.
  - Removed the fabricated "ABOUT THE ROLE / KEY RESPONSIBILITIES / WHAT WE
    OFFER" boilerplate that was silently substituted for real descriptions
    under 150 chars. That was inventing job-posting content and presenting
    it as if it came from the employer — misleading to anyone reading it.
    Short descriptions are now left as-is with a link to the real listing.
  - `/sources` now reports each source's tier and which bot-defense (if any)
    it sits behind.
- `docker-compose.yml` — removed the `obscura` (headless Chrome anti-detect
  proxy) service and the `OBSCURA_WS_URL` env var, since nothing reads it
  anymore. Also moved the Adzuna/Reed API keys that were hardcoded in plain
  text in this file to environment-variable substitution (`${ADZUNA_APP_ID}`
  etc.) — **rotate those two keys**, since they were committed to the repo
  in cleartext.
- `requirements.txt` — removed `playwright-stealth`.
- `test_all_scrapers.py`, `test_all_8.py`, `test_scraper.py` — updated to
  read the new `ScraperResult` shape (`result.status`, `result.jobs`,
  `result.reason`) instead of treating `search()`'s return value as a bare list.

## Post-review fix
`careerjet.py` and `cvlibrary.py` called `BrowserClient(executable_path=None)`.
When `browser_client.py` was simplified, that constructor argument was
dropped, breaking both call sites (`TypeError: unexpected keyword argument
'executable_path'`). Fixed by updating both call sites to `BrowserClient()` --
`executable_path` was always passed as `None` anyway, so nothing is lost.

## Still there, not removed (needs a manual call from you)
- `Dockerfile.obscura` and `test_obscura.py` are now dead (nothing launches
  or connects to that image anymore) but I left the files in place rather
  than deleting them, in case you want to repurpose that Chrome container
  for legitimate headless rendering of the JS-hydrated, non-blocked sources
  (SEEK/Glassdoor) instead of throwing the container away. Delete both if
  you don't need that.

## What this means for Indeed/Monster/Workopolis/Totaljobs/StepStone
They will now return a **503 with an explicit reason** (e.g. `"Blocked by
Totaljobs (Akamai Bot Manager): akamai signature detected: 'access denied'
(HTTP 403)"`) instead of a silent empty list. That's the correct, honest
end state until they're backed by an official feed integration.
