from typing import List, Dict, Any
from app.scrapers.base import BaseScraper
from app.models.filters import SearchFilters
from app.core.errors import BlockedSourceError, detect_block_signature
from bs4 import BeautifulSoup
import httpx
import logging
from fake_useragent import UserAgent

logger = logging.getLogger(__name__)


class TotaljobsScraper(BaseScraper):
    """
    Totaljobs scraper (UK market). Totaljobs is protected by Akamai Bot
    Manager. One honest HTTP attempt; if Akamai's block page is returned,
    raises BlockedSourceError rather than attempting to defeat it.

    Real fix: Totaljobs is part of StepStone Group, which offers a partner /
    B2B job feed API for aggregators. Use that instead of scraping.
    """

    def __init__(self):
        super().__init__()
        self.source_name = "Totaljobs"
        self.base_url = "https://www.totaljobs.com/jobs/"
        self.ua = UserAgent()

    async def get_jobs(self, filters: SearchFilters, page: int = 1) -> List[Dict[str, Any]]:
        all_jobs = []
        keyword = (filters.keyword or filters.company or "developer").replace(" ", "-").lower()
        location = (filters.city or filters.country or "London").replace(" ", "-").lower()

        url = f"https://www.totaljobs.com/jobs/{keyword}/in-{location}"
        if page > 1:
            url += f"?page={page}"

        logger.info(f"[Totaljobs] Fetching: {url}")
        headers = {
            'User-Agent': self.ua.random,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-GB,en;q=0.5',
        }

        try:
            async with httpx.AsyncClient(timeout=8.0, follow_redirects=True, headers=headers) as client:
                resp = await client.get(url)
        except httpx.RequestError as e:
            raise BlockedSourceError("Totaljobs", f"network error reaching Totaljobs: {e}")

        block = detect_block_signature(resp.status_code, resp.text[:3000])
        if block:
            provider, marker = block
            raise BlockedSourceError("Totaljobs (Akamai Bot Manager)", f"{provider} signature detected: '{marker}' (HTTP {resp.status_code})")

        if resp.status_code != 200:
            raise BlockedSourceError("Totaljobs", f"unexpected HTTP {resp.status_code}")

        soup = BeautifulSoup(resp.text, "html.parser")
        job_cards = (
            soup.find_all("article", attrs={"data-at": "job-item"})
            or soup.find_all("div", class_=lambda c: c and "job-card" in c.lower())
            or soup.find_all("article")
        )

        for card in job_cards:
            try:
                job_data = {}
                title_elem = card.find("h2") or card.find("a", attrs={"data-at": "job-item-title"})
                if not title_elem:
                    continue
                job_data["title"] = title_elem.get_text(strip=True)

                link_elem = card.find("a", href=True)
                job_data["job_url"] = (
                    link_elem["href"] if link_elem and link_elem["href"].startswith("http")
                    else f"https://www.totaljobs.com{link_elem['href']}" if link_elem else ""
                )
                job_data["id"] = str(abs(hash(job_data["job_url"])))[:10]

                company_elem = card.find(attrs={"data-at": "job-item-company-name"}) or card.find("span", class_=lambda c: c and "company" in c.lower())
                job_data["company"] = company_elem.get_text(strip=True) if company_elem else "Totaljobs Employer"

                loc_elem = card.find(attrs={"data-at": "job-item-location"}) or card.find("span", class_=lambda c: c and "location" in c.lower())
                job_data["location_raw"] = loc_elem.get_text(strip=True) if loc_elem else location

                if job_data["title"] and job_data["job_url"]:
                    all_jobs.append(job_data)
            except Exception:
                continue

        return all_jobs

    async def get_job_details(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        return raw_job

    async def normalize(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        loc_raw = raw_job.get("location_raw", "")
        city, country = loc_raw, "United Kingdom"
        if "," in loc_raw:
            parts = loc_raw.split(",")
            city = parts[0].strip()

        return {
            "id": str(raw_job.get("id", "")),
            "title": raw_job.get("title", ""),
            "company": raw_job.get("company", "Totaljobs Partner"),
            "country": country,
            "state": None,
            "city": city or "London",
            "remote": "remote" in loc_raw.lower() or "home" in loc_raw.lower(),
            "employment_type": None,
            "salary_min": None,
            "salary_max": None,
            "currency": "GBP",
            "job_url": raw_job.get("job_url", ""),
            "apply_url": raw_job.get("job_url", ""),
            "description": raw_job.get("description", ""),
            "posted_date": raw_job.get("date", ""),
            "open_time": raw_job.get("date", ""),
            "close_time": None,
            "source": self.source_name,
            "company_logo": None,
            "applicants": None
        }
