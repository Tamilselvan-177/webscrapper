from typing import List, Dict, Any
from app.scrapers.base import BaseScraper
from app.models.filters import SearchFilters
from app.core.errors import BlockedSourceError, detect_block_signature
from bs4 import BeautifulSoup
import httpx
import logging
import urllib.parse
from fake_useragent import UserAgent

logger = logging.getLogger(__name__)


class IndeedScraper(BaseScraper):
    """
    Indeed scraper (also powers Monster, Workopolis via factory mappings).

    Indeed is protected by Cloudflare Turnstile. This scraper makes ONE honest
    HTTP attempt with normal headers. If Cloudflare's challenge page comes
    back, it raises BlockedSourceError with the detected signature rather than
    trying to defeat the challenge (no headless-browser stealth, no
    fingerprint spoofing -- that code path has been removed on purpose).

    To actually get real Indeed jobs, integrate Indeed's official Publisher /
    XML Feed program instead of scraping. See README section on official feeds.
    """

    def __init__(self):
        super().__init__()
        self.source_name = "Indeed"
        self.base_url = "https://www.indeed.com/jobs"
        self.ua = UserAgent()

    async def get_jobs(self, filters: SearchFilters, page: int = 1) -> List[Dict[str, Any]]:
        all_jobs = []
        start = (page - 1) * 10

        keyword = " ".join(filter(None, [filters.keyword, filters.company])) or "developer"
        location = " ".join(filter(None, [filters.city, filters.country])) or "London"

        url = f"{self.base_url}?q={urllib.parse.quote(keyword)}&l={urllib.parse.quote(location)}&start={start}"

        logger.info(f"[Indeed] Fetching: {url}")
        headers = {
            'User-Agent': self.ua.random,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
        }

        try:
            async with httpx.AsyncClient(timeout=8.0, follow_redirects=True, headers=headers) as client:
                resp = await client.get(url)
        except httpx.RequestError as e:
            raise BlockedSourceError("Indeed", f"network error reaching Indeed: {e}")

        block = detect_block_signature(resp.status_code, resp.text[:3000])
        if block:
            provider, marker = block
            raise BlockedSourceError("Indeed (Cloudflare Turnstile)", f"{provider} signature detected: '{marker}' (HTTP {resp.status_code})")

        if resp.status_code != 200:
            raise BlockedSourceError("Indeed", f"unexpected HTTP {resp.status_code}")

        soup = BeautifulSoup(resp.text, "html.parser")
        job_cards = (
            soup.find_all("div", class_="job_seen_beacon")
            or soup.find_all("div", attrs={"data-jk": True})
            or soup.find_all("div", class_=lambda c: c and "job_seen_beacon" in c)
        )

        for card in job_cards:
            try:
                job_data = {}
                jk = card.get("data-jk") or card.find(attrs={"data-jk": True})
                if hasattr(jk, "get"):
                    jk = jk.get("data-jk", "")
                job_data["id"] = str(jk) if jk else ""

                title_elem = card.find("h2", class_="jobTitle") or card.find("span", {"title": True})
                job_data["title"] = title_elem.get_text(strip=True) if title_elem else ""

                company_elem = card.find("span", attrs={"data-testid": "company-name"}) or card.find(class_="companyName")
                job_data["company"] = company_elem.get_text(strip=True) if company_elem else "Indeed Partner"

                loc_elem = card.find("div", attrs={"data-testid": "text-location"}) or card.find(class_="companyLocation")
                job_data["location_raw"] = loc_elem.get_text(strip=True) if loc_elem else location

                date_elem = card.find("span", attrs={"data-testid": "myJobsStateDate"}) or card.find(class_="date")
                job_data["date"] = date_elem.get_text(strip=True) if date_elem else ""

                if job_data["id"]:
                    job_data["job_url"] = f"https://www.indeed.com/viewjob?jk={job_data['id']}"
                else:
                    link = card.find("a", href=True)
                    job_data["job_url"] = "https://www.indeed.com" + link["href"] if link else ""

                if job_data.get("title") and job_data.get("id"):
                    all_jobs.append(job_data)
            except Exception:
                continue

        return all_jobs

    async def get_job_details(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        return raw_job

    async def normalize(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        loc_raw = raw_job.get("location_raw", "")
        city, country = loc_raw, None
        if "," in loc_raw:
            parts = loc_raw.split(",")
            city = parts[0].strip()
            country = parts[-1].strip()

        return {
            "id": str(raw_job.get("id", "")),
            "title": raw_job.get("title", ""),
            "company": raw_job.get("company", "Indeed Employer"),
            "country": country or "United Kingdom",
            "state": None,
            "city": city or "London",
            "remote": "remote" in loc_raw.lower(),
            "employment_type": None,
            "salary_min": None,
            "salary_max": None,
            "currency": "GBP" if country == "United Kingdom" or "UK" in str(country) else "USD",
            "job_url": raw_job.get("job_url", ""),
            "apply_url": raw_job.get("job_url", ""),
            "description": raw_job.get("description", ""),
            "posted_date": raw_job.get("date", ""),
            "open_time": raw_job.get("date", ""),
            "close_time": None,
            "source": self.source_name,
            "company_logo": None,
            "applicants": None
        }
