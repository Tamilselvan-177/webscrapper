"""
app/scrapers/description_fetcher.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Shared utility for fetching FULL job descriptions from job detail pages.

Most job boards show a truncated snippet on the listing page with a
"Show more" / "See full description" button that requires JavaScript.
This module fetches the detail URL via plain HTTP and extracts the
complete description using site-specific CSS selectors.

CHANGE NOTE: the previous version of this file auto-escalated to a headless
browser with playwright-stealth evasions ("bypass bot detection (Cloudflare,
etc.)") any time a source returned 403/429/503. That auto-escalation has been
removed project-wide -- it doesn't matter which source triggers it, retrying
a bot-defense block with a stealth browser is the same bypass regardless of
which file it lives in.

What's left:
  - Plain HTTP fetch + CSS-selector extraction (works for any non-protected
    source; this is the bulk of real usage).
  - An explicit, narrow headless-render path for sources that are NOT behind
    enterprise bot-defense but DO require JS hydration to show content
    (e.g. SEEK, Glassdoor client-side rendering). This uses a plain
    Chromium context with no stealth/evasion flags, and it is only ever
    called for sources in JS_RENDER_ALLOWLIST below -- never as a reaction
    to a 403/429/503, since that reaction is exactly the bypass pattern.

If a source starts returning bot-defense signatures (Cloudflare/Akamai/etc.),
the fix is to raise BlockedSourceError in that scraper's get_jobs(), not to
add it here.
"""

import re
import logging
import httpx
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from typing import Dict, Any, List, Optional

from app.core.errors import detect_block_signature

logger = logging.getLogger(__name__)
_ua = UserAgent()

# Sources confirmed to NOT sit behind enterprise bot-defense, where a plain
# (non-stealth) headless render is used only because the description content
# is JS-hydrated. If any of these starts showing block signatures, remove it
# from this list and raise BlockedSourceError in its scraper instead.
JS_RENDER_ALLOWLIST = {"seek", "jora", "glassdoor"}

SELECTORS: Dict[str, List[str]] = {
    "indeed": [
        "#jobDescriptionText",
        '[class*="jobsearch-jobDescriptionText"]',
        '[id*="jobDescription"]',
        ".job-description",
    ],
    "adzuna": [
        ".job-description",
        '[class*="description"]',
        '[id*="description"]',
        "article.job-listing",
        "main article",
    ],
    "glassdoor": [
        '[class*="JobDetails_jobDescription"]',
        '[data-test="description"]',
        ".jobDescriptionContent",
        "#JobDescriptionContainer",
        '[class*="desc"]',
    ],
    "totaljobs": [
        ".job-description",
        '[class*="job-description"]',
        "#job-description",
        "article .content",
        ".description-container",
    ],
    "stepstone": [
        '[data-testid="job-description"]',
        ".at-section-text-description",
        '[class*="jobAd__content"]',
        ".js-job-description",
    ],
    "reed": [
        "#job-description",
        '[itemprop="description"]',
        ".description",
        ".job-details__description",
    ],
    "seek": [
        '[data-automation="jobAdDetails"]',
        '[class*="jobAdDetails"]',
        ".jobDetailsContainer",
        ".job-content",
    ],
    "jora": [
        ".job-description",
        '[class*="description"]',
        "article",
    ],
    "jobrapido": [
        ".job_description",
        ".description",
        '[class*="description"]',
    ],
    "irishjobs": [
        '[class*="description"]',
        '[data-testid="job-description"]',
        ".job-description",
        "article",
    ],
    "jobsireland": [
        ".job-description",
        '[class*="description"]',
        "main article",
    ],
    "workopolis": [
        ".job-description",
        '[class*="description"]',
        ".content",
    ],
    "michaelpage": [
        ".job-description",
        '[class*="content"]',
        ".richtext",
    ],
    "randstad": [
        ".job-description",
        '[class*="description"]',
        ".content-block",
    ],
    "hays": [
        ".job-description",
        ".content-block",
        '[class*="description"]',
    ],
    "linkedin": [
        ".description__text",
        ".jobs-description__content",
        '[class*="description__text"]',
        ".job-view-layout",
    ],
    "monster": [
        "#JobDescription",
        ".job-description",
        '[class*="description"]',
    ],
    "__fallback__": [
        '[class*="description"]',
        '[id*="description"]',
        '[class*="job-detail"]',
        '[id*="job-detail"]',
        "article",
        "main",
    ],
}


def _clean_html(html_or_text: str) -> str:
    """Convert an HTML fragment to clean plain text."""
    if not html_or_text:
        return ""
    text = html_or_text
    text = re.sub(r"<button[^>]*>.*?</button>", "", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(p|div|h[1-6]|li|tr|section|article)>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<li[^>]*>", "• ", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    replacements = {
        "&amp;": "&", "&lt;": "<", "&gt;": ">",
        "&nbsp;": " ", "&#39;": "'", "&quot;": '"',
        "&ndash;": "–", "&mdash;": "—", "&bull;": "•",
    }
    for entity, char in replacements.items():
        text = text.replace(entity, char)
    text = re.sub(r"\b(Show|See|Read)\s+(more|less|full description|job details?)\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\b(Expand|Collapse|See full description)\b", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


def _extract_from_soup(soup: BeautifulSoup, source: str) -> Optional[str]:
    """Try site-specific selectors, then generic fallback."""
    selectors = SELECTORS.get(source.lower(), []) + SELECTORS["__fallback__"]
    for selector in selectors:
        try:
            elem = soup.select_one(selector)
            if elem:
                text = _clean_html(str(elem))
                if len(text) > 200:
                    return text
        except Exception:
            continue
    return None


async def _render_with_plain_headless_browser(url: str, selector: Optional[str], source: str) -> str:
    """
    Plain (non-stealth) headless Chromium render, used ONLY for sources in
    JS_RENDER_ALLOWLIST that need JS hydration to show their description --
    not for evading any bot-defense. No stealth plugin, no evasion flags.
    """
    if source.lower() not in JS_RENDER_ALLOWLIST:
        return ""
    if not url or url == "#":
        return ""
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        logger.warning("[DescFetcher] Playwright not installed; skipping JS render.")
        return ""

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            try:
                context = await browser.new_context(
                    viewport={"width": 1280, "height": 800},
                    locale="en-AU" if source.lower() in ("seek", "jora") else "en-US",
                )
                page = await context.new_page()
                await page.goto(url, timeout=15000, wait_until="domcontentloaded")
                html = await page.content()
            finally:
                await browser.close()
    except Exception as e:
        logger.debug(f"[DescFetcher:{source}] JS render error: {e}")
        return ""

    soup = BeautifulSoup(html, "html.parser")
    if selector:
        elem = soup.select_one(selector)
        if elem:
            text = _clean_html(str(elem))
            if len(text) > 200:
                return text
    return _extract_from_soup(soup, source) or ""


async def fetch_full_description(
    raw_job: Dict[str, Any],
    source: str = "",
    min_length: int = 300,
) -> Dict[str, Any]:
    """
    Fetch the full job description from the job detail page via plain HTTP.
    For the small allowlist of JS-hydrated (not bot-defended) sources, falls
    back to a plain headless render. Any 403/429/503 is logged and left as-is
    -- it is NOT treated as a trigger to retry with a stealth browser.
    """
    existing_desc = (raw_job.get("description") or "").strip()
    is_truncated = existing_desc.endswith("...") or existing_desc.endswith("…")

    if len(existing_desc) >= min_length and not is_truncated:
        return raw_job

    job_url = raw_job.get("job_url") or raw_job.get("apply_url") or ""
    if not job_url or job_url == "#":
        return raw_job

    if source.lower() in JS_RENDER_ALLOWLIST:
        selector = '[data-automation="jobAdDetails"]' if source.lower() == "seek" else None
        full_text = await _render_with_plain_headless_browser(job_url, selector, source)
        if full_text and len(full_text) > len(existing_desc):
            logger.info(f"[DescFetcher:{source}] Fetched full description via JS render ({len(full_text)} chars)")
            raw_job["description"] = full_text
        return raw_job

    headers = {
        "User-Agent": _ua.random,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-GB,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control": "no-cache",
    }

    try:
        async with httpx.AsyncClient(timeout=10.0, follow_redirects=True, headers=headers) as client:
            resp = await client.get(job_url)

            block = detect_block_signature(resp.status_code, resp.text[:2000] if resp.status_code != 200 else "")
            if block or resp.status_code in (403, 401, 429, 503):
                logger.info(
                    f"[DescFetcher:{source}] Detail page blocked (HTTP {resp.status_code}); "
                    f"leaving existing snippet as-is (no bypass attempted)."
                )
                return raw_job

            if resp.status_code != 200:
                logger.debug(f"[DescFetcher:{source}] HTTP {resp.status_code} for {job_url}")
                return raw_job

            soup = BeautifulSoup(resp.text, "html.parser")
            full_text = _extract_from_soup(soup, source)

            if full_text and len(full_text) > len(existing_desc):
                logger.info(f"[DescFetcher:{source}] Fetched full description ({len(full_text)} chars) from {job_url}")
                raw_job["description"] = full_text

    except httpx.TimeoutException:
        logger.debug(f"[DescFetcher:{source}] Timeout fetching {job_url}")
    except Exception as e:
        logger.debug(f"[DescFetcher:{source}] Error fetching {job_url}: {e}")

    return raw_job
