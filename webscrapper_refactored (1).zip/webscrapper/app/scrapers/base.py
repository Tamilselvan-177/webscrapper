from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import asyncio
import logging
import httpx
from pydantic import ValidationError
from app.models.job import JobSchema
from app.models.filters import SearchFilters
from app.core.http_client import HTTPClient
from app.core.errors import (
    ScraperFetchError,
    ScraperValidationError,
    BlockedSourceError,
    ScraperResult,
    SourceStatus,
)

logger = logging.getLogger(__name__)


class BaseScraper(ABC):
    """
    Abstract base class for all job scrapers implementing the Template Method Pattern.
    """

    def __init__(self):
        self.source_name: str = "base"
        self.base_url: str = ""
        self.client: Optional[HTTPClient] = None

    async def search(self, filters: SearchFilters) -> ScraperResult:
        """
        Template method orchestrating the search:
        fetches raw jobs, iterates, normalizes, validates, and reports status.

        Returns a ScraperResult -- callers must check `.status` rather than
        assuming an empty `.jobs` list means "no matches". `.status` will be
        BLOCKED (with a reason) when perimeter bot-defense stopped the fetch.
        """
        normalized_jobs: List[JobSchema] = []
        try:
            logger.info(f"[{self.source_name}] Starting search for company '{filters.company}'")
            raw_jobs = await self.get_jobs(filters)

            sem = asyncio.Semaphore(8)  # 2 requests per job (listing + detail) -- keep below rate limits

            async def process_job(raw_job):
                async with sem:
                    try:
                        job_detail = await self.get_job_details(raw_job)

                        try:
                            from app.scrapers.description_fetcher import fetch_full_description
                            job_detail = await fetch_full_description(
                                job_detail,
                                source=self.source_name,
                                min_length=700,
                            )
                        except Exception as _desc_err:
                            logger.debug(f"[{self.source_name}] desc fetch skipped: {_desc_err}")

                        job_dict = await self.normalize(job_detail)
                        return JobSchema.model_validate(job_dict)

                    except ValidationError as ve:
                        logger.error(f"[{self.source_name}] Schema validation failed for job: {ve}")
                    except Exception as e:
                        logger.error(f"[{self.source_name}] Error processing job: {e}")
                    return None

            results = await asyncio.gather(*[process_job(job) for job in raw_jobs])
            for validated_job in results:
                if validated_job is not None:
                    normalized_jobs.append(validated_job)

        except BlockedSourceError as e:
            logger.warning(f"[{self.source_name}] BLOCKED: {e}")
            return ScraperResult(
                source=self.source_name,
                status=SourceStatus.BLOCKED,
                jobs=[],
                reason=str(e),
            )
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning(f"[{self.source_name}] Company not found (404).")
                return ScraperResult(self.source_name, SourceStatus.NOT_FOUND, [], "404 from source")
            logger.error(f"[{self.source_name}] HTTP Error: {e}")
            return ScraperResult(self.source_name, SourceStatus.ERROR, [], f"HTTP error: {e}")
        except Exception as e:
            logger.error(f"[{self.source_name}] Unexpected Error: {e}")
            return ScraperResult(self.source_name, SourceStatus.ERROR, [], f"Unexpected error: {e}")

        logger.info(f"[{self.source_name}] Successfully validated {len(normalized_jobs)} jobs.")
        return ScraperResult(self.source_name, SourceStatus.OK, normalized_jobs, None)

    @abstractmethod
    async def get_jobs(self, filters: SearchFilters, page: int = 1) -> List[Dict[str, Any]]:
        """
        Fetches the raw job listings from the source.

        Implementations must raise BlockedSourceError (see app.core.errors)
        when they detect enterprise bot-defense (Cloudflare Turnstile, Akamai
        Bot Manager, etc.) rather than silently returning an empty list, and
        must NOT attempt to defeat that defense.
        """
        pass

    @abstractmethod
    async def get_job_details(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fetches detailed information if required, or just returns raw_job if details are included.
        """
        pass

    @abstractmethod
    async def normalize(self, raw_job: Dict[str, Any]) -> Dict[str, Any]:
        """
        Converts the raw source data into a dictionary matching the JobSchema fields.
        """
        pass

    async def close(self):
        if self.client:
            await self.client.close()
