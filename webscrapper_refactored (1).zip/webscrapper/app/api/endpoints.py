from fastapi import APIRouter, Query, Path, HTTPException
from typing import List, Optional, Dict, Any
from app.models.job import JobSchema
from app.models.filters import SearchFilters
from app.scrapers.factory import get_scraper, get_source_tier, SOURCE_TIERS
from app.core.errors import SourceStatus
import re

router = APIRouter()


def clean_description(desc: str) -> str:
    """
    Strip HTML tags and remove common job-board 'Show more' button artifacts
    so we get clean plain text for the description field.
    """
    if not desc:
        return ""
    desc = re.sub(r'<button[^>]*>.*?</button>', '', desc, flags=re.IGNORECASE | re.DOTALL)
    desc = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', desc, flags=re.IGNORECASE | re.DOTALL)
    desc = re.sub(r'<br\s*/?>', '\n', desc, flags=re.IGNORECASE)
    desc = re.sub(r'</(p|div|h[1-6]|li|tr)>', '\n', desc, flags=re.IGNORECASE)
    desc = re.sub(r'<li[^>]*>', '• ', desc, flags=re.IGNORECASE)
    desc = re.sub(r'<[^>]+>', '', desc)
    desc = desc.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&nbsp;', ' ').replace('&#39;', "'").replace('&quot;', '"')
    desc = re.sub(r'\bShow (more|less|full description|job details?)\b', '', desc, flags=re.IGNORECASE)
    desc = re.sub(r'\b(See more|See less|Read more|Expand|Collapse)\b', '', desc, flags=re.IGNORECASE)
    desc = re.sub(r'\n{3,}', '\n\n', desc)
    desc = re.sub(r'[ \t]{2,}', ' ', desc)
    return desc.strip()


async def enrich_jobs(jobs: List[JobSchema], source: str) -> List[JobSchema]:
    """
    Enrich real, scraped job data. This does NOT fabricate content: if a
    description is short/generic, it is left as-is (with the source link
    intact) rather than replaced with invented "ABOUT THE ROLE" boilerplate
    -- that was misleading job seekers into reading generated text as if it
    were the employer's real posting.
    """
    for job in jobs:
        if not job.company_logo or str(job.company_logo).lower() == "none" or "http" not in str(job.company_logo):
            clean_company = re.sub(
                r'[^a-zA-Z0-9]', '',
                (job.company or "company").lower()
                .replace("inc", "").replace("ltd", "").replace("gmbh", "")
                .replace("uk", "").replace("careers", "").replace("group", "")
                .replace("ireland", "").replace("australia", "")
            )
            if clean_company:
                job.company_logo = f"https://www.google.com/s2/favicons?domain={clean_company}.com&sz=128"

        if source:
            job.source = source.capitalize()

        if job.description:
            job.description = clean_description(job.description)

        desc = (job.description or "").strip()
        if len(desc) < 150:
            # Honest placeholder -- no invented facts, points to the real listing.
            job.description = (
                (desc + "\n\n" if desc else "")
                + f"Full description not fully captured from the listing page. "
                  f"View the complete posting here: {job.job_url}"
            )

    return jobs


@router.get("/jobs", summary="Search jobs across ATS sources")
async def search_jobs(
    source: str = Query(..., description="The source ATS to scrape (e.g. greenhouse, lever, smartrecruiters, personio, ashby)"),
    company: Optional[str] = Query(None, description="The company slug to search for (e.g. 'contentful' for Greenhouse)"),
    keyword: Optional[str] = Query(None, description="Search by keyword or job title"),
    country: Optional[str] = Query(None, description="Filter by country"),
    city: Optional[str] = Query(None, description="Filter by city"),
    remote: Optional[bool] = Query(None, description="Filter for remote jobs"),
    salary_min: Optional[float] = Query(None, description="Minimum salary"),
    employment_type: Optional[str] = Query(None, description="e.g. Full-time, Part-time"),
    page: int = Query(1, description="Pagination page (if supported by source)")
):
    """
    Scrape and search for jobs dynamically from a supported source.

    Response shape:
        {
          "status": "ok" | "blocked" | "not_found" | "error",
          "reason": str | null,      # populated when status != "ok"
          "source_tier": {...},      # whether this source is a live scrape or
                                      # pending an official-API integration
          "jobs": [ ... JobSchema ... ]
        }

    A "blocked" status with an empty jobs list means perimeter bot-defense
    (Cloudflare/Akamai/etc.) stopped the fetch -- it is NOT the same as "no
    matching jobs", and callers should render/handle it differently.
    """
    try:
        scraper = get_scraper(source)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    filters = SearchFilters(
        source=source,
        company=company,
        keyword=keyword,
        country=country,
        city=city,
        remote=remote,
        salary_min=salary_min,
        employment_type=employment_type,
        page=page
    )

    try:
        result = await scraper.search(filters)
        jobs = await enrich_jobs(result.jobs, source)

        response = {
            "status": result.status.value,
            "reason": result.reason,
            "source_tier": get_source_tier(source),
            "count": len(jobs),
            "jobs": jobs,
        }

        if result.status == SourceStatus.BLOCKED:
            # Surface this loudly rather than a quiet 200/empty-list --
            # an agent or UI consuming this should treat it as "source
            # unavailable", not "zero results for your search".
            raise HTTPException(status_code=503, detail=response)

        return response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Scraper failed: {str(e)}")
    finally:
        await scraper.close()


@router.get("/jobs/{job_id}", response_model=JobSchema, summary="Get details for a specific job")
async def get_job_details(
    job_id: str = Path(..., description="The ID of the job"),
    source: str = Query(..., description="The ATS source"),
    company: str = Query(..., description="The company slug")
):
    """
    Fetch the detailed information for a specific job ID.
    """
    try:
        scraper = get_scraper(source)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        filters = SearchFilters(company=company, source=source)
        result = await scraper.search(filters)

        if result.status == SourceStatus.BLOCKED:
            raise HTTPException(status_code=503, detail={
                "status": result.status.value,
                "reason": result.reason,
                "source_tier": get_source_tier(source),
            })

        jobs = await enrich_jobs(result.jobs, source)
        for job in jobs:
            if job.id == job_id:
                return job
        raise HTTPException(status_code=404, detail="Job not found on source")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Scraper failed: {str(e)}")
    finally:
        await scraper.close()


@router.get("/sources", summary="List supported sources and their status")
async def get_sources():
    """
    Returns all ATS platforms currently supported, along with whether each is
    a live direct scrape or currently blocked pending an official-API
    integration (Indeed/Monster/Workopolis -- Cloudflare Turnstile;
    Totaljobs/StepStone -- Akamai Bot Manager).
    """
    all_sources = [
        "greenhouse", "lever", "smartrecruiters", "personio", "ashby",
        "adzuna", "reed", "careerjet", "linkedin", "indeed", "glassdoor",
        "seek", "totaljobs", "cvlibrary", "stepstone", "randstad",
        "michaelpage", "hays", "xing", "jobrapido", "irishjobs",
        "jobsireland", "eures", "workopolis", "jora", "monster",
        "careerone", "eluta", "workforceaustralia",
    ]
    return {
        "sources": [
            {"name": s, **get_source_tier(s)} for s in all_sources
        ]
    }


@router.get("/countries", response_model=List[str], summary="List supported countries")
async def get_countries():
    return [
        "Germany", "United Kingdom", "France", "Netherlands", "Spain",
        "Italy", "Sweden", "Ireland", "Switzerland", "Austria"
    ]


@router.get("/states", response_model=List[str], summary="List supported states/regions")
async def get_states():
    return ["Berlin", "Bavaria", "Île-de-France", "Catalonia", "Lombardy"]


@router.get("/cities", response_model=List[str], summary="List supported cities")
async def get_cities():
    return ["Berlin", "London", "Paris", "Amsterdam", "Madrid", "Munich", "Stockholm", "Dublin"]


@router.get("/companies", response_model=List[str], summary="List known companies")
async def get_companies():
    return ["contentful", "n26", "personio", "lever", "smartrecruiters"]


@router.get("/skills", response_model=List[str], summary="List available skills")
async def get_skills():
    return ["Python", "FastAPI", "React", "TypeScript", "Rust", "Go", "Kubernetes", "AWS"]
