from playwright.async_api import async_playwright, Browser, Page
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class BrowserClient:
    """
    Plain headless-Chromium client for sources that need JS rendering to show
    content (e.g. client-side-hydrated listing/description pages).

    CHANGE NOTE: this previously applied playwright-stealth evasions by
    default and could route through a remote "Obscura" anti-detect browser
    engine via OBSCURA_WS_URL -- i.e. it was bot-defense-bypass infrastructure
    shared across every caller, whether or not that caller actually needed it.
    That has been removed. This class now does plain rendering only.

    If a source you're calling this for turns out to sit behind enterprise
    bot-defense (Cloudflare/Akamai/etc.), the correct fix is to raise
    BlockedSourceError in that scraper -- not to make this client stealthier.
    """

    def __init__(self):
        self.playwright = None
        self.browser: Optional[Browser] = None

    async def start(self):
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(headless=True)

    async def get_page(self) -> Page:
        if not self.browser:
            await self.start()

        context = await self.browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            locale='en-US',
        )
        return await context.new_page()

    async def close(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
