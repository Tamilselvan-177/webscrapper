"""
app/core/errors.py
~~~~~~~~~~~~~~~~~~~
Shared status/error types so every scraper reports *why* it returned
zero jobs, instead of silently returning an empty list that looks the
same whether the source has no matches or is actively blocking us.

Design rule enforced here: when a scraper detects an enterprise bot-defense
challenge (Cloudflare Turnstile, Akamai Bot Manager, etc.) it must raise
BlockedSourceError with the detected signature. Scrapers must NOT attempt to
defeat that challenge (headless-browser stealth, fingerprint spoofing,
CAPTCHA solving, residential proxy rotation, etc.) — that code path has been
removed project-wide. Blocked sources should be replaced with an official
API/partner feed integration, not a scraping workaround.
"""

from enum import Enum
from typing import List, Optional, Any
from dataclasses import dataclass, field


class SourceStatus(str, Enum):
    OK = "ok"                 # Fetched successfully (may still be 0 jobs = no matches)
    BLOCKED = "blocked"       # Enterprise bot-defense (Cloudflare/Akamai/etc.) rejected the request
    NOT_FOUND = "not_found"   # Source returned 404 / company or query genuinely not found
    ERROR = "error"           # Network error, parsing error, timeout, etc.


class ScraperFetchError(Exception):
    """Generic, non-block-related fetch failure (timeout, parse error, 5xx)."""
    pass


class ScraperValidationError(Exception):
    """A raw job failed schema validation."""
    pass


class BlockedSourceError(Exception):
    """
    Raised when a scraper detects it has been stopped by perimeter bot-defense
    (Cloudflare Turnstile, Akamai Bot Manager, PerimeterX, DataDome, etc.)

    `signature` should record the concrete evidence (status code, page title,
    challenge marker) so it's visible in logs/API responses — not just "blocked".
    """
    def __init__(self, provider: str, signature: str):
        self.provider = provider
        self.signature = signature
        super().__init__(f"Blocked by {provider}: {signature}")


# Known bot-defense fingerprints. Used only to LABEL what happened — never to
# decide "so let's try to get around it."
BOT_DEFENSE_SIGNATURES = {
    "cloudflare_turnstile": ["just a moment", "cf-turnstile", "checking your browser", "__cf_chl"],
    "akamai": ["access denied", "ak_bmsc", "reference #", "bm-verify"],
    "perimeterx": ["px-captcha", "perimeterx"],
    "datadome": ["datadome"],
}


def detect_block_signature(status_code: int, body_snippet: str) -> Optional[tuple]:
    """
    Inspect a response for known bot-defense fingerprints.
    Returns (provider_name, matched_marker) or None if nothing matched.
    """
    lowered = (body_snippet or "").lower()
    for provider, markers in BOT_DEFENSE_SIGNATURES.items():
        for marker in markers:
            if marker in lowered:
                return provider, marker
    if status_code in (403, 429, 503) and not lowered:
        return "unknown_perimeter_defense", f"http_{status_code}"
    return None


@dataclass
class ScraperResult:
    """Wrapper returned by BaseScraper.search() so callers get status + reason,
    not just a possibly-empty list."""
    source: str
    status: SourceStatus
    jobs: List[Any] = field(default_factory=list)
    reason: Optional[str] = None
